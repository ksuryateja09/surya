function showInterface(id) {
    document.querySelectorAll('.interface').forEach(el => el.classList.remove('visible'));
    document.getElementById(`interface${id}`).classList.add('visible');
}

function loadImage(event) {
    const reader = new FileReader();
    reader.onload = function() {
        const img = document.createElement('img');
        img.src = reader.result;
        img.className = 'note-image';
        document.getElementById('noteText').appendChild(img);
    };
    reader.readAsDataURL(event.target.files[0]);
}

function addPage() {
    const page = document.createElement('div');
    page.className = 'page';
    page.innerHTML = `
        <textarea placeholder="New page content..." class="textarea"></textarea>
        <button class="page-button" onclick="this.parentElement.remove()">Remove Page</button>
    `;
    document.getElementById('pages').appendChild(page);
}

function saveNote() {
    const noteName = document.getElementById('noteName').value;
    const noteText = document.getElementById('noteText').value;
    const pages = Array.from(document.querySelectorAll('#pages .page')).map(page => page.querySelector('textarea').value);
    
    if (noteName && noteText) {
        notes.push({ name: noteName, text: noteText, pages });
        displaySavedNotes();
        showInterface(3);
    } else {
        alert('Please enter a note title and content.');
    }
}

function displaySavedNotes() {
    const savedNotesContainer = document.getElementById('savedNotes');
    savedNotesContainer.innerHTML = '';
    notes.forEach(note => {
        const noteElement = document.createElement('div');
        noteElement.className = 'saved-note';
        noteElement.innerHTML = `
            <h3>${note.name}</h3>
            <p>${note.text}</p>
            ${note.pages.map(page => `<p>${page}</p>`).join('')}
        `;
        savedNotesContainer.appendChild(noteElement);
    });
}

// Initialize an empty array to store notes
const notes = [];